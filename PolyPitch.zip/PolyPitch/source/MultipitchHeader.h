//
//  MultipitchHeader.h
//  Multipitch
//
//  Created by Nicholas Collins on 29/05/2011.

//this code is under GNU GPL3 license, see file COPYING enclosed

#pragma once

#include <iostream>
#include <math.h>
#include "samplerate.h"
#include "SC_PlugIn.h"

//sampling rate assumed at 44100
const float g_samplingrate = 44100.f; 
const float g_sampleperiod = 2.2675736961451e-05f; 

const int g_ppwindowsize = 2048; 
const int g_ppdecimatedwindowsize = 256; 
const int g_Uksize = 256; 

extern InterfaceTable *ft; 


//build with accelerate framework directly, bypassing SC fft (new version of which is SC 3.5+ only)
#define OSXACCELERATENOTSCFFT